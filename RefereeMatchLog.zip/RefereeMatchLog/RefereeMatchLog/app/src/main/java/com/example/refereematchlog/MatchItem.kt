package com.example.refereematchlog

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "match_items")
data class MatchItem(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val matchName: String,
    val fee: Int,
    val isPaid: Boolean = false
)
