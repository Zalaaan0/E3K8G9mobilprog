package com.example.refereematchlog

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    MatchLogScreen()
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MatchLogScreen(viewModel: MatchViewModel = viewModel()) {
    val matchList by viewModel.matches.collectAsState()

    var matchNameInput by remember { mutableStateOf("") }
    var feeInput by remember { mutableStateOf("") }
    var editingItem by remember { mutableStateOf<MatchItem?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Játékvezetői Meccsnyilvántartó") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer
                )
            )
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .padding(16.dp)
        ) {
            OutlinedTextField(
                value = matchNameInput,
                onValueChange = { matchNameInput = it },
                label = { Text("Mérkőzés (pl. Edelény - Sajóbábony)") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(8.dp))

            OutlinedTextField(
                value = feeInput,
                onValueChange = { feeInput = it },
                label = { Text("Díjazás (Ft)") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))

            Row(modifier = Modifier.fillMaxWidth()) {
                Button(
                    onClick = {
                        val feeValue = feeInput.toIntOrNull() ?: 0
                        if (matchNameInput.isNotBlank() && feeValue > 0) {
                            if (editingItem == null) {
                                viewModel.addMatch(matchNameInput.trim(), feeValue)
                            } else {
                                viewModel.updateMatch(
                                    editingItem!!.copy(
                                        matchName = matchNameInput.trim(),
                                        fee = feeValue
                                    )
                                )
                                editingItem = null
                            }
                            matchNameInput = ""
                            feeInput = ""
                        }
                    },
                    modifier = Modifier.weight(1f)
                ) {
                    Text(if (editingItem == null) "Mérkőzés hozzáadása" else "Módosítás mentése")
                }

                if (editingItem != null) {
                    Spacer(modifier = Modifier.width(8.dp))
                    OutlinedButton(
                        onClick = {
                            editingItem = null
                            matchNameInput = ""
                            feeInput = ""
                        }
                    ) {
                        Text("Mégse")
                    }
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(matchList, key = { it.id }) { item ->
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Checkbox(
                                checked = item.isPaid,
                                onCheckedChange = { checked ->
                                    viewModel.updateMatch(item.copy(isPaid = checked))
                                }
                            )

                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = item.matchName,
                                    fontWeight = FontWeight.Bold,
                                    textDecoration = if (item.isPaid) TextDecoration.LineThrough else TextDecoration.None
                                )
                                Text(
                                    text = "Díjazás: ${item.fee} Ft" + if (item.isPaid) " (Kifizetve)" else "",
                                    style = MaterialTheme.typography.bodySmall
                                )
                            }

                            IconButton(
                                onClick = {
                                    editingItem = item
                                    matchNameInput = item.matchName
                                    feeInput = item.fee.toString()
                                }
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = "Szerkesztés")
                            }

                            IconButton(
                                onClick = { viewModel.deleteMatch(item) }
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Törlés")
                            }
                        }
                    }
                }
            }
        }
    }
}
