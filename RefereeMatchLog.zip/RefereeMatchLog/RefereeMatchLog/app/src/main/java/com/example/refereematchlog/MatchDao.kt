package com.example.refereematchlog

import androidx.room.*
import kotlinx.coroutines.flow.Flow

@Dao
interface MatchDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMatch(item: MatchItem)

    @Query("SELECT * FROM match_items ORDER BY id DESC")
    fun getAllMatches(): Flow<List<MatchItem>>

    @Update
    suspend fun updateMatch(item: MatchItem)

    @Delete
    suspend fun deleteMatch(item: MatchItem)
}
