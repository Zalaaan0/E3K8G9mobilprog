package com.example.refereematchlog

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class MatchViewModel(application: Application) : AndroidViewModel(application) {
    private val dao = MatchDatabase.getDatabase(application).matchDao()

    val matches: StateFlow<List<MatchItem>> = dao.getAllMatches()
        .stateIn(
            scope = viewModelScope,
            started = SharingStarted.WhileSubscribed(5000),
            initialValue = emptyList()
        )

    fun addMatch(matchName: String, fee: Int) {
        viewModelScope.launch {
            dao.insertMatch(MatchItem(matchName = matchName, fee = fee))
        }
    }

    fun updateMatch(item: MatchItem) {
        viewModelScope.launch {
            dao.updateMatch(item)
        }
    }

    fun deleteMatch(item: MatchItem) {
        viewModelScope.launch {
            dao.deleteMatch(item)
        }
    }
}
